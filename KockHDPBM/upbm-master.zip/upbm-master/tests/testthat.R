library("testthat")
library("upbm")

test_check("upbm")
